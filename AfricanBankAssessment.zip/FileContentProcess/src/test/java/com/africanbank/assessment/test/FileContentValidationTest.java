package com.africanbank.assessment.test;

import org.junit.Test;

import com.africanbank.assessment.FileContentProcess;

/**
 * @author SreenivasaRao Ayineni
 *
 */
public class FileContentValidationTest {

	@Test
	public void testFileContent() throws Exception
	{
		try
		{
		String fileNameOne = "textfile1.txt";
		String fileNameTwo = "textfile2.txt";
		String filename3 = "file3.txt";
		String filename4 = "file4.txt";
		FileContentProcess fileContentProcess1 = new FileContentProcess();
		System.out.println("------------TechnicalTest Case 1-------------------");
		fileContentProcess1.doFilecontentProcess(fileNameOne, fileNameTwo);	
		
		System.out.println("------------TechnicalTest Case 2 -------------------");
		FileContentProcess fileContentProcess2 = new FileContentProcess();
		fileContentProcess2.doFilecontentProcess(filename3, filename4);	
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
}
