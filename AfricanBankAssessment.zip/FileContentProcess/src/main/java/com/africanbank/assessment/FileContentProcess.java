package com.africanbank.assessment;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.Set;
import java.util.HashSet;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;

public class FileContentProcess {

	private static final String IPREGEX = "(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)";
	private static final String COMMA_SEPERATED_REGEX ="^[-+]?(?:[0-9]+,)*[0-9]+(?:\\.[0-9]+)?$";
	private  Map<String, String> processingValues = new TreeMap<String, String>();
	private  Map<String, String> invalidValues = new TreeMap<String, String>();
	private static int FIRST_ELEMENT = 0;
	private static int FILE_PARAMETER_COUNT = 0;
	private static long FILE_CONTENT_LENGTH = 0;
	private static int INVALID_TEST_RESULTS_COUNT = 0;
	private static int FILES_COUNT_IN_DIRECTORY = 0;
	/**
	 * @author Sreenivasarao Ayineni
	 * @param args
	 * @throws Exception 
	 */
	
	public static void main(String[] args) throws Exception {
		//doFilecontentProcess(args[0],args[1]);
	}
	
	public void doFilecontentProcess(String fileName1,String fileName2) throws Exception {	
	    
	    try  
	  	{  
	  	String path = "C:\\TechnicalTest\\";
	  	File file = new File(path);
	  	String args[] = {fileName1,fileName2};
	  	boolean noContent = false;
	  	if(file.isDirectory())
	  	{
	  		if (file.listFiles().length == FILES_COUNT_IN_DIRECTORY)
	  		{
	  			System.out.println(" Zero Files in the folder");
	  		}
	  	}
	  	
	  	if (args.length > FILE_PARAMETER_COUNT )
		 {
			  	for (int k=0;k<args.length;k++)
			  	{
			  		file = new File(path+args[k].toString().trim());
			  		if (file.isFile() && file.length() > FILE_CONTENT_LENGTH)
			  		{
					  	FileReader fileReader=new FileReader(file);   
					  	BufferedReader bufferReder=new BufferedReader(fileReader);  
					  	String line;  
					  	
					  	while((line=bufferReder.readLine())!=null)  
					  	{  
					  		processFile(line);
					  	}  
					  	fileReader.close();
			  		}
			  		else
			  		{
			  			System.out.println(" The file "+file.getName()+" contains invalid content ");
			  			noContent = true;
			  		}
			  	}	
			  	
			  	if (!noContent)
			  	{
				  	//System.out.println("Results - Expected Results"); 
				  	for (String output:processingValues.keySet())
				  	{
				  		System.out.println(output+":"+applySort(processingValues.get(output)));
				  	}
				  	
				  	if(invalidValues.keySet().size() > INVALID_TEST_RESULTS_COUNT)
				  	{
					  	System.out.println("\n");
					  	System.out.println("Results - Invalid file content list"); 
					  	for (String output:invalidValues.keySet())
					  	{	  		
					  		System.out.println(output+":"+invalidValues.get(output));
					  	} 
				  	}
				  	
			  	}
		  	}
		  	else
		  	{
		  		System.out.println(" Please prvoide input parameters as file name(s) ");
		  	}
	  	}  
	    
	  	catch(IOException e)  
	  	{  
	  		System.out.println("Invalid file content or Invalid file(s)");
	  		//e.printStackTrace();  
	  	}  
	      
	     
	   }
	
	public void processFile(String line)
	{
		StringTokenizer stringTokenizer = new StringTokenizer(line,":");  
	    String ipaddress = "";
	    try
	    {
	     while (stringTokenizer.hasMoreTokens())
	     {  
	    	ipaddress = stringTokenizer.nextToken();
	    	
	        Pattern p = Pattern.compile(IPREGEX);
	        Matcher m = p.matcher(ipaddress.trim());
	         if(m.find()) {
	        	 ipaddress = m.group(0);		         
		         String commaSeperatedValues = stringTokenizer.nextToken();
			        Pattern p2 = Pattern.compile(COMMA_SEPERATED_REGEX);
			        Matcher m2 = p2.matcher(commaSeperatedValues.trim());
			        if(m2.find()) {
				        if (!processingValues.containsKey(ipaddress)){
				        	processingValues.put(ipaddress, commaSeperatedValues);
				        }
				        else
				        {
				        	processingValues.put(ipaddress, (processingValues.get(ipaddress)+","+commaSeperatedValues));				        	
				        }
			        }
			        else
			        {
			        	// Invalid comma seperated value(s)
			        	invalidValues.put(ipaddress, commaSeperatedValues);
			        }
		      }
	         else
	         {
	        	 try
	        	 {
	        		 invalidValues.put(ipaddress, stringTokenizer.nextToken());
	        	 }
	        	 catch(Exception e)
	        	 {
	        		 System.out.println("Invalid content in file \n");
	        	 }
	        	 
	        	 // Invalid IP Address
	         }	
	         
	     	}  	
	    }
	    catch(Exception e)
	    {
	    	System.out.println("Invalid file content");
	    }
	}
	
	private String applySort(String value) throws Exception
    {
      String []target=value.split(",");
      Integer []targets= new Integer[target.length];
      try
      {
	      for (int i=0;i<target.length;i++)
	      {
	    	  targets[i] = Integer.parseInt(target[i].toString());
	      }
	      Arrays.sort(targets);
      }
      catch(Exception e)
      {
		System.out.println("Sorting issue: Invalid content in comma seperated values");
		throw new Exception("Sorting issue: Invalid content in comma seperated values");
      }
      return removeDuplicates(targets);
    }
	private String removeDuplicates(Integer []target) throws Exception
	{	
		String returnValue="";
		int setsize=0;
		Set<Integer> set = new HashSet<Integer>();
		try
		{
			for(int i=0;i<target.length;i++)
		    {
				set.add(target[i]);
		    }      
			
			for (Iterator it = (Iterator) set.iterator(); it.hasNext(); )
			{			
				if (setsize==set.size() || setsize==FIRST_ELEMENT )
				{
					returnValue = returnValue+ it.next();
				}
				else
				{
					returnValue = returnValue+","+ it.next();
				}
				setsize++;
		    }
		}
		catch(Exception e)
		{
			System.out.println("Duplication removal issue: Invalid content in comma seperated values");
			throw new Exception("Duplication removal issue: Invalid content in comma seperated values");
		}
	    return returnValue;
	}
}
